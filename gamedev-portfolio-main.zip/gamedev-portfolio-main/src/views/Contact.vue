<template>
  <div>
    
    <h1>Let's get in touch</h1>

    <div style="margin-bottom:40px;">I'm looking for a job !<br/>Feel free to contact me about any opportunity, or just to chat about cooking, kittens or anything else.</div>

    <ul>
      <li>
        <i class="fa fa-user-circle-o fa-lg fa-fw"></i>
        <a href="http://mywebsite.com" target="_blank">https://mywebsite.com</a>
      </li>
      <li>
        <i class="fa fa-envelope-o fa-lg fa-fw"></i>
        <a href="mailto:my@email.com" target="_blank">my@email.com</a>
      </li>
      <li>
        <i class="fa fa-linkedin fa-lg fa-fw" style="vertical-align: -5%;"></i>
        <a href="https://www.linkedin.com/me" target="_blank">linkedin.com/me</a>
      </li>
      <li>
        <i class="fa fa-github fa-lg fa-fw"></i>
        <a href="https://github.com/me" target="_blank">github.com/me</a>
      </li>
      <li>
        <i class="fa fa-gamepad fa-lg fa-fw"></i>
        <a href="https://myself.itch.io" target="_blank">myself.itch.io</a>
      </li>
      <li>
        <i class="fa fa-tumblr fa-lg fa-fw"></i>
        <a href="https://myblog.tumblr.com" target="_blank">myblog.tumblr.com</a>
      </li>
      <li>
        <i class="fa fa-steam fa-lg fa-fw"></i>
        <a href="https://steamcommunity.com/id/me" target="_blank">steam.com/me</a>
      </li>
    </ul>

  </div>
</template>

<style scoped>
ul {
  list-style: none;
  padding-inline-start: 0px;
}

li {
    line-height: 1.8em;
    font-size: 1.2em;
  }

@media only screen and (min-width: 620px){
  ul {
    padding-inline-start: 40px;
  }

  li {
    line-height: 2em;
    font-size: 1.4em;
  }
}

i {
  margin-right: 20px;
}
</style>
